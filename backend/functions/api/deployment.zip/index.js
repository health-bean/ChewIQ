const { handleCors } = require('./middleware/cors');
const { handleAuth } = require('./handlers/auth');
const { handleGetUser, handleUpdateUser, handleGetUserProtocols, handleGetUserPreferences, handleUpdateUserPreferences } = require('./handlers/users');
const { handleGetJournalEntries, handleCreateJournalEntry, handleGetJournalEntry, handleUpdateJournalEntry } = require('./handlers/journal');
const { handleGetTimelineEntries, handleCreateTimelineEntry } = require('./handlers/timeline');
const { handleGetProtocols } = require('./handlers/protocols');
const { handleSearchFoods } = require('./handlers/foods');
const { handleSearchSymptoms } = require('./handlers/symptoms');
const { handleSearchSupplements } = require('./handlers/supplements');
const { handleSearchMedications } = require('./handlers/medications');
const { handleSearchDetoxTypes } = require('./handlers/detox');
const { successResponse, errorResponse } = require('./utils/responses');

exports.handler = async (event) => {
    console.log('Event:', JSON.stringify(event, null, 2));
    
    const corsResponse = handleCors(event);
    if (corsResponse) return corsResponse;
    
    try {
        const path = event.path;
        const method = event.httpMethod;
        const body = event.body ? JSON.parse(event.body) : {};
        const pathParams = event.pathParameters || {};
        const queryParams = event.queryStringParameters || {};
        
        console.log(`${method} ${path}`);
        
        let response;
        
        if (path === '/api/v1/auth' && method === 'POST') {
            response = await handleAuth(body);
        }
        else if (path === '/api/v1/users' && method === 'GET') {
            response = await handleGetUser(event);
        }
        else if (path === '/api/v1/users' && method === 'POST') {
            response = await handleUpdateUser(body, event);
        }
        else if (path === '/api/v1/user/protocols' && method === 'GET') {
            response = await handleGetUserProtocols(event);
        }
        else if (path === '/api/v1/protocols' && method === 'GET') {
            response = await handleGetProtocols(queryParams, event);
        }
        else if (path === '/api/v1/foods/search' && method === 'GET') {
            response = await handleSearchFoods(queryParams, event);
        }
        else if (path === '/api/v1/symptoms/search' && method === 'GET') {
            response = await handleSearchSymptoms(queryParams, event);
        }
        else if (path === '/api/v1/supplements/search' && method === 'GET') {
            response = await handleSearchSupplements(queryParams, event);
        }
        else if (path === '/api/v1/medications/search' && method === 'GET') {
            response = await handleSearchMedications(queryParams, event);
        }
        else if (path === '/api/v1/detox-types/search' && method === 'GET') {
            response = await handleSearchDetoxTypes(queryParams, event);
        }
        else if (path === '/api/v1/journal/entries' && method === 'GET') {
            response = await handleGetJournalEntries(queryParams, event);
        }
        else if (path === '/api/v1/journal/entries' && method === 'POST') {
            response = await handleCreateJournalEntry(body, event);
        }
        else if (path.startsWith('/api/v1/journal/entries/') && method === 'PUT') {
            const date = path.split('/').pop();
            response = await handleUpdateJournalEntry(date, body, event);
        }
        else if (path.startsWith('/api/v1/journal/entries/') && method === 'GET') {
            const date = path.split('/').pop();
            response = await handleGetJournalEntry(date, event);
        }
        else if (path === '/api/v1/timeline/entries' && method === 'GET') {
            response = await handleGetTimelineEntries(queryParams, event);
        }
        else if (path === '/api/v1/timeline/entries' && method === 'POST') {
            response = await handleCreateTimelineEntry(body, event);
        }
        else if (path === '/api/v1/user/preferences' && method === 'GET') {
            response = await handleGetUserPreferences(event);
        }
        else if (path === '/api/v1/user/preferences' && method === 'POST') {
            response = await handleUpdateUserPreferences(body, event);
        }
        else {
            response = handleNotFound(path, method);
        }
        
        
        return response;
        
    } catch (error) {
        console.error('Error:', error);
        return errorResponse('Internal server error: ' + error.message, 500);
    }
};

const handleNotFound = (path, method) => {
    return errorResponse('Endpoint not found', 404, {
        path: path,
        method: method,
        availableEndpoints: [
            'POST /api/v1/auth',
            'GET /api/v1/users',
            'POST /api/v1/users',
            'GET /api/v1/user/protocols',
            'GET /api/v1/protocols',
            'GET /api/v1/foods/search',
            'GET /api/v1/symptoms/search',
            'GET /api/v1/supplements/search',
            'GET /api/v1/medications/search',
            'GET /api/v1/detox-types/search',
            'GET /api/v1/journal/entries',
            'POST /api/v1/journal/entries',
            'GET /api/v1/journal/entries/:date',
            'PUT /api/v1/journal/entries/:date',
            'GET /api/v1/timeline/entries',
            'POST /api/v1/timeline/entries',
            'GET /api/v1/user/preferences',
            'POST /api/v1/user/preferences'
        ]
    });
};