const { Pool } = require('pg');

// Database connection pool
const pool = new Pool({
    host: 'health-platform-dev-db.c5njva4wrrhe.us-east-1.rds.amazonaws.com',
    port: 5432,
    database: 'health_platform_dev',
    user: 'healthadmin',
    password: 'TempPassword123!',
    ssl: {
        rejectUnauthorized: false
    }
});

// CORS headers for all responses
const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
    'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS'
};

// Main Lambda handler
exports.handler = async (event) => {
    console.log('Event:', JSON.stringify(event, null, 2));
    
    // Handle preflight requests
    if (event.httpMethod === 'OPTIONS') {
        return {
            statusCode: 200,
            headers: corsHeaders,
            body: JSON.stringify({ message: 'CORS preflight' })
        };
    }
    
    try {
        // Extract route information
        const path = event.path;
        const method = event.httpMethod;
        const body = event.body ? JSON.parse(event.body) : {};
        const pathParams = event.pathParameters || {};
        const queryParams = event.queryStringParameters || {};
        
        console.log(`${method} ${path}`);
        
        // Route handling
        let response;
        
        if (path === '/api/v1/auth' && method === 'POST') {
            response = await handleAuth(body);
        }
        else if (path === '/api/v1/users' && method === 'GET') {
            response = await handleGetUser(event);
        }
        else if (path === '/api/v1/users' && method === 'POST') {
            response = await handleUpdateUser(body, event);
        }
        else if (path === '/api/v1/journal/entries' && method === 'GET') {
            response = await handleGetJournalEntries(queryParams, event);
        }
        else if (path === '/api/v1/journal/entries' && method === 'POST') {
            response = await handleCreateJournalEntry(body, event);
        }
        else if (path.startsWith('/api/v1/journal/entries/') && method === 'PUT') {
            const date = path.split('/').pop();
            response = await handleUpdateJournalEntry(date, body, event);
        }
        else if (path.startsWith('/api/v1/journal/entries/') && method === 'GET') {
            const date = path.split('/').pop();
            response = await handleGetJournalEntry(date, event);
        }
        else {
            response = await handleNotFound(path, method);
        }
        
        return {
            statusCode: response.statusCode || 200,
            headers: corsHeaders,
            body: JSON.stringify(response.data)
        };
        
    } catch (error) {
        console.error('Error:', error);
        return {
            statusCode: 500,
            headers: corsHeaders,
            body: JSON.stringify({
                error: 'Internal server error',
                message: error.message
            })
        };
    }
};

// Authentication endpoint
async function handleAuth(body) {
    const { action, email, password, firstName, lastName } = body;
    
    if (action === 'register') {
        // For now, return success - we'll add Cognito integration later
        return {
            statusCode: 201,
            data: {
                message: 'User registration initiated',
                email: email,
                status: 'pending_verification'
            }
        };
    }
    
    if (action === 'login') {
        // For now, return mock success - we'll add Cognito integration later
        return {
            statusCode: 200,
            data: {
                message: 'Login successful',
                token: 'mock-jwt-token',
                user: {
                    id: 'user-123',
                    email: email,
                    role: 'patient'
                }
            }
        };
    }
    
    return {
        statusCode: 400,
        data: { error: 'Invalid action. Use "login" or "register"' }
    };
}

// Get current user profile
async function handleGetUser(event) {
    // For now, return mock user - we'll add JWT validation later
    const mockUser = {
    id: '123e4567-e89b-12d3-a456-426614174000',
    email: 'patient@example.com',
    firstName: 'John',
    lastName: 'Doe', 
    role: 'patient',
    tenantId: '123e4567-e89b-12d3-a456-426614174001',
    // ...
};
    
    return {
        statusCode: 200,
        data: { user: mockUser }
    };
}

// Update user profile
async function handleUpdateUser(body, event) {
    // For now, return success - we'll add database update later
    return {
        statusCode: 200,
        data: {
            message: 'User profile updated successfully',
            updatedFields: Object.keys(body)
        }
    };
}

// Get journal entries (list)
async function handleGetJournalEntries(queryParams, event) {
    try {
        const client = await pool.connect();
        
        // Mock tenant and user for now - will get from JWT later
        const userId = '123e4567-e89b-12d3-a456-426614174000';
        const tenantId = '123e4567-e89b-12d3-a456-426614174001';
        
        // Get entries from database - simplified to match actual schema
        const query = `
            SELECT 
                entry_date,
                bedtime,
                wake_time,
                sleep_quality,
                overall_feeling,
                stress_level,
                created_at,
                updated_at
            FROM journal_entries 
            WHERE user_id = $1 AND tenant_id = $2
            ORDER BY entry_date DESC
            LIMIT 30
        `;
        
        const result = await client.query(query, [userId, tenantId]);
        client.release();
        
        return {
            statusCode: 200,
            data: {
                entries: result.rows,
                total: result.rows.length
            }
        };
        
    } catch (error) {
        console.error('Database error:', error);
        return {
            statusCode: 500,
            data: { error: 'Failed to fetch journal entries' }
        };
    }
}

// Create new journal entry
async function handleCreateJournalEntry(body, event) {
    try {
        const client = await pool.connect();
        
        // Mock tenant and user for now
        const userId = '123e4567-e89b-12d3-a456-426614174000';
        const tenantId = '123e4567-e89b-12d3-a456-426614174001';
        
        const {
            entryDate,
            bedtime,
            wakeTime,
            sleepQuality,
            overallFeeling,
            stressLevel
        } = body;
        
        // Insert journal entry - simplified schema
        const query = `
            INSERT INTO journal_entries (
                tenant_id, user_id, entry_date, bedtime, wake_time,
                sleep_quality, overall_feeling, stress_level
            ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
            ON CONFLICT (tenant_id, user_id, entry_date) 
            DO UPDATE SET
                bedtime = EXCLUDED.bedtime,
                wake_time = EXCLUDED.wake_time,
                sleep_quality = EXCLUDED.sleep_quality,
                overall_feeling = EXCLUDED.overall_feeling,
                stress_level = EXCLUDED.stress_level,
                updated_at = NOW()
            RETURNING *
        `;
        
        const values = [
            tenantId, userId, entryDate, bedtime, wakeTime,
            sleepQuality, overallFeeling, stressLevel
        ];
        
        const result = await client.query(query, values);
        client.release();
        
        return {
            statusCode: 201,
            data: {
                message: 'Journal entry created successfully',
                entry: result.rows[0]
            }
        };
        
    } catch (error) {
        console.error('Database error:', error);
        return {
            statusCode: 500,
            data: { error: 'Failed to create journal entry' }
        };
    }
}

// Get specific journal entry by date
async function handleGetJournalEntry(date, event) {
    try {
        const client = await pool.connect();
        
        const userId = '123e4567-e89b-12d3-a456-426614174000';
        const tenantId = '123e4567-e89b-12d3-a456-426614174001';
        
        const query = `
            SELECT * FROM journal_entries 
            WHERE user_id = $1 AND tenant_id = $2 AND entry_date = $3
        `;
        
        const result = await client.query(query, [userId, tenantId, date]);
        client.release();
        
        if (result.rows.length === 0) {
            return {
                statusCode: 404,
                data: { error: 'Journal entry not found for this date' }
            };
        }
        
        return {
            statusCode: 200,
            data: { entry: result.rows[0] }
        };
        
    } catch (error) {
        console.error('Database error:', error);
        return {
            statusCode: 500,
            data: { error: 'Failed to fetch journal entry' }
        };
    }
}

// Update journal entry by date
async function handleUpdateJournalEntry(date, body, event) {
    try {
        const client = await pool.connect();
        
    const userId = '123e4567-e89b-12d3-a456-426614174000';
    const tenantId = '123e4567-e89b-12d3-a456-426614174001';
        
        // Build dynamic update query based on provided fields
        const updateFields = [];
        const values = [];
        let valueIndex = 1;
        
        const fieldMapping = {
            bedtime: 'bedtime',
            wakeTime: 'wake_time',
            sleepQuality: 'sleep_quality',
            overallFeeling: 'overall_feeling',
            stressLevel: 'stress_level'
        };
        
        for (const [bodyField, dbField] of Object.entries(fieldMapping)) {
            if (body[bodyField] !== undefined) {
                updateFields.push(`${dbField} = $${valueIndex}`);
                values.push(body[bodyField]);
                valueIndex++;
            }
        }
        
        if (updateFields.length === 0) {
            return {
                statusCode: 400,
                data: { error: 'No valid fields provided for update' }
            };
        }
        
        updateFields.push(`updated_at = NOW()`);
        values.push(userId, tenantId, date);
        
        const query = `
            UPDATE journal_entries 
            SET ${updateFields.join(', ')}
            WHERE user_id = $${valueIndex} AND tenant_id = $${valueIndex + 1} AND entry_date = $${valueIndex + 2}
            RETURNING *
        `;
        
        const result = await client.query(query, values);
        client.release();
        
        if (result.rows.length === 0) {
            return {
                statusCode: 404,
                data: { error: 'Journal entry not found for this date' }
            };
        }
        
        return {
            statusCode: 200,
            data: {
                message: 'Journal entry updated successfully',
                entry: result.rows[0]
            }
        };
        
    } catch (error) {
        console.error('Database error:', error);
        return {
            statusCode: 500,
            data: { error: 'Failed to update journal entry' }
        };
    }
}

// Handle 404 - Not Found
async function handleNotFound(path, method) {
    return {
        statusCode: 404,
        data: {
            error: 'Endpoint not found',
            path: path,
            method: method,
            availableEndpoints: [
                'POST /api/v1/auth',
                'GET /api/v1/users',
                'POST /api/v1/users',
                'GET /api/v1/journal/entries',
                'POST /api/v1/journal/entries',
                'GET /api/v1/journal/entries/:date',
                'PUT /api/v1/journal/entries/:date'
            ]
        }
    };
}